'''
import re
uncleanText = open("Nifty50data.txt").read()
cleanText = re.sub('[^A-Za-z0-9\s\n:\'/.]+', '', uncleanText)
open('words.txt', 'w').write(cleanText)

'''
import pandas as pd

data = pd.read_csv('words.txt', header = None)

df = pd.DataFrame(data)

#d= df.columns.str.split()

#print(df[0])

#x = df[0]

#x.split()
df.index

